# Instructions on how to run
1. Make sure you are in the same directory as the Makefile
2. Make sure you have sourced the cross compiling environment for the chipKIT Uno32
3. Make sure the chipKIT is connected to your computer
4. Run "make" to compile
5. Run "make install" or, if the first doesn't work, "make install TTYDEV=/dev/path-to-serial-port"
