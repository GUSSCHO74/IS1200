#pragma once

#include <stdbool.h>
#include <stdint.h>
#include "Alignment.h"
#include "Animation.h"
#include "helper.h"
#include "Rect.h"

#define OLED_SET_COMMAND_MODE (PORTFCLR = 0x10)
#define OLED_SET_DATA_MODE    (PORTFSET = 0x10)

#define FPS 50

#define DISPLAY_BUFFER_SIZE 512
#define DISPLAY_SIZE_X      128
#define DISPLAY_SIZE_Y       32
#define DISPLAY_ROWS          4
#define DISPLAY_CENTER (Vector2f){DISPLAY_SIZE_X / 2, DISPLAY_SIZE_Y / 2}

#define PIXEL_ON  1
#define PIXEL_OFF 0

#define FLIP_ON  1
#define FLIP_OFF 0

#define HOLLOW_ON  1
#define HOLLOW_OFF 0

#define BACKGROUND_ON  1
#define BACKGROUND_OFF 0

typedef struct
{
	uint8_t buffer[DISPLAY_BUFFER_SIZE];
	int8_t char_spacing;
	bool inverse;
} Display;

void SPI_put_byte(uint8_t byte);

void Display_update_row(uint8_t *buffer);
void Display_update    (Display *display);
void Display_clear     (Display *display);

void Display_put_pixel           (Display *display, int x, int y, bool pixel);
void Display_draw_horizontal_line(Display *display, Vector2f position, int length, bool pixel);
void Display_draw_vertical_line  (Display *display, Vector2f position, int length, bool pixel);
void Display_draw_rect           (Display *display, Rect rect, bool hollow, bool pixel);

/*
	note: flipping bitmaps is only implemented horizontally
*/

void Display_draw_bitmap     (Display *display, const uint8_t *bitmap,            Vector2f position, bool flip, bool pixel);
void Display_draw_bitmap_crop(Display *display, const uint8_t *bitmap, Rect crop, Vector2f position, bool flip, bool pixel);

void Display_draw_animation(Display *display, const uint8_t *bitmap_animation, uint8_t frame_size, uint8_t frame, Vector2f position, bool flip, bool pixel);

void Display_draw_char  (Display *display, char c, Vector2f position, bool flip, bool pixel);
void Display_draw_string(Display *display, const char *string, Vector2f position, Alignment align_x, Alignment align_y, bool flip, bool pixel, bool background);
