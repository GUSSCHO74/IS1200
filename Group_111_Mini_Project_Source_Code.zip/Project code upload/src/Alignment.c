#include "Alignment.h"

/*
	this function is able to align something with a given position and size relative to itself,
	depending on the specified alignment in the x and y axes.
*/
Vector2f align(Vector2f position, Vector2f size, Alignment align_x, Alignment align_y)
{
	switch (align_x)
	{
		case ALIGN_START:
			// nothing needs to be done
			break;

		case ALIGN_CENTER:
			position.x -= size.x / 2;
			break;

		case ALIGN_STOP:
			position.x -= size.x;
			break;
	}

	switch (align_y)
	{
		case ALIGN_START:
			// nothing needs to be done
			break;

		case ALIGN_CENTER:
			position.y -= size.y / 2;
			break;

		case ALIGN_STOP:
			position.y -= size.y;
			break;
	}

	return position;
}
