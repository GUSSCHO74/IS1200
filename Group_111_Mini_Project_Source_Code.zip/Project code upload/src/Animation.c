#include "Animation.h"
#include "bitmaps.h"

Animation Animation_construct(const uint8_t *bitmap, uint8_t frames)
{
	Animation animation;

	animation.bitmap = bitmap;
	animation.bitmap_width = bitmap_get_width(bitmap);
	animation.bitmap_height = bitmap_get_height(bitmap);
	animation.frame_size = animation.bitmap_width / frames;

	return animation;
}
