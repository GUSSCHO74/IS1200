#pragma once

#include <pic32mx.h>
#include <stdbool.h>
#include <stdint.h>

#define LED_PORT PORTE

bool get_LED(uint8_t index);
void set_LED(uint8_t index, bool bit);
