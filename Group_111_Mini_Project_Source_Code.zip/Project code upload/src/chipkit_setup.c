#include <pic32mx.h>
#include "LED.h"
#include "Display.h"
#include "chipkit_setup.h"

/*
	SPI_init() and OLED_init() were largely influenced by the main() (line 271)
	and display_init() (line 184) functions respectively from:
	https://github.com/is1200-example-projects/hello-display/blob/master/main.c
	Further influenced by the examples in the "chipKIT Basic I/O Shield Reference Manual" starting at page 9:
	https://digilent.com/reference/_media/chipkit_shield_basic_io_shield:chipkit_basic_io_shield_rm.pdf
*/

void sleep_ms(unsigned int ms)
{
	int i;
	for (i = 0; i < ms; i++)
	{
		for (;;)
		{
			if (IFS(0) & T3_IFS_MASK)
			{
				IFSCLR(0) = T3_IFS_MASK;
				break;
			}
		}
	}
}

void SPI_init()
{
	// Output pins for the display signals
	TRISFCLR = 0x70;
	TRISGCLR = 0x200;

	// Set CKP = 1, MSTEN = 1
	SPI2CON = 0x60;
	// Turn on SPI
	SPI2CONSET = 0x8000;

	// Timer 2, used for contolling the speed at which the game is updated
	T2CON    = 0;                  // clear control register
	           //x...............
	T2CONSET = 0b1000000000000000; // enable timer
	           //.........xxx....
	T2CONSET = 0b0000000001110000; // enable 1:256 prescaling
	TMR2     = 0;                  // clear timer register
	PR2      = 6250;               // set period register, (frequency / prescaling) / fps = (80 000 000 / 256) / 50 = 6250

	// Timer 3, used for waiting a certain amount of milliseconds during setup of OLED display
	T3CON    = 0;                  // clear control register
	           //x...............
	T3CONSET = 0b1000000000000000; // enable timer
	           //.........xxx....
	T3CONSET = 0b0000000001100000; // enable 1:64 prescaling
	TMR3     = 0;                  // clear timer register
	PR3      = 1250;               // set period register, (frequency / prescaling) / milliseconds per second = (80 000 000 / 64) / 1000 = 1250
}

void OLED_init()
{
	OLED_SET_COMMAND_MODE;
	sleep_ms(100);
	PORTFCLR = 0x40;            // Turn on VDD
	sleep_ms(100);

	SPI_put_byte(0xAE);
	PORTGCLR = 0x200;           // Bring reset low
	sleep_ms(100);
	PORTGSET = 0x200;           // Bring reset high
	sleep_ms(100);

	SPI_put_byte(0x8D);
	SPI_put_byte(0x14);

	SPI_put_byte(0xD9);
	SPI_put_byte(0xF1);

	PORTFCLR = 0x20;            // Turn on VCC
	sleep_ms(100);

	// Invert the display so that the origin is in the upper left corner
	SPI_put_byte(0xA1);
	SPI_put_byte(0xC8);

	SPI_put_byte(0xDA);
	SPI_put_byte(0x20);

	// Send Display On command
	SPI_put_byte(0xAF);
}

void chipkit_setup()
{
	SPI_init();
	OLED_init();

	// enabling all LEDs
	TRISECLR = 0b11111111;
	// turning off all LEDs
	LED_PORT = 0;
}
