#pragma once

#include <stdint.h>

#define SETTINGS_MIN 1
#define SETTINGS_MAX 6

#define SETTINGS_DEFAULT_HEALTH 3
#define SETTINGS_DEFAULT_BULLET_SPEED 4
#define SETTINGS_DEFAULT_SHOOT_DELAY_FRAMES 4
#define SETTINGS_DEFAULT_INVINCIBILITY_FRAMES 3

#define SETTINGS_MULTIPLIER_HEALTH 1
#define SETTINGS_MULTIPLIER_BULLET_SPEED 0.5
#define SETTINGS_MULTIPLIER_SHOOT_DELAY_FRAMES 5
#define SETTINGS_MULTIPLIER_INVINCIBILITY_FRAMES 20

typedef struct
{
	uint8_t health;
	uint8_t bullet_speed;
	uint8_t shoot_delay_frames;
	uint8_t invincibility_frames;
} Settings;

void Settings_reset(Settings *settings);
void Settings_change_setting(Settings *settings, uint8_t setting_index, int delta);
