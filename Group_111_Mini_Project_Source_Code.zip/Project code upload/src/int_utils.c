#include "int_utils.h"

/*
	returns the exponential value of num to the power of exponent
*/
int int_pow(int num, uint8_t exponent)
{
	int powed = 1;
	uint8_t i;
	for (i = 0; i < exponent; i++)
		powed *= num;
	return powed;
}

/*
	returns the number of digits in a number
*/
uint8_t int_digit_count(int num)
{
	if (num < 0) num = -num;

	uint8_t count = 1;

	int highest_digit_value = 1;

	while (num >= (highest_digit_value *= 10))
	{
		count++;
	}

	return count;
}
