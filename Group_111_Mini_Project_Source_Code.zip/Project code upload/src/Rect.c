#include "Rect.h"

Rect Rect_construct(Vector2f position, Vector2f size)
{
	Rect rect;
	rect.position = position;
	rect.size = size;
	return rect;
}

float Rect_get_top(Rect *rect)
{
	return rect->position.y;
}

float Rect_get_bottom(Rect *rect)
{
	return rect->position.y + rect->size.y;
}

float Rect_get_left(Rect *rect)
{
	return rect->position.x;
}

float Rect_get_right(Rect *rect)
{
	return rect->position.x + rect->size.x;
}

void Rect_set_top(Rect *rect, float top)
{
	rect->position.y = top;
}

void Rect_set_bottom(Rect *rect, float bottom)
{
	rect->position.y = bottom - rect->size.y;
}

void Rect_set_left(Rect *rect, float left)
{
	rect->position.x = left;
}

void Rect_set_right(Rect *rect, float right)
{
	rect->position.x = right - rect->size.x;
}

/*
	returns a boolean representing whether or not a point is contained inside a rectangle
*/
bool Rect_contains(Rect *rect, Vector2f point)
{
	return point.x >= rect->position.x && point.x < rect->position.x + rect->size.x
	       &&
	       point.y >= rect->position.y && point.y < rect->position.y + rect->size.y;
}

/*
	returns a boolean representing whether or not two rectangles overlap
*/
bool Rect_overlap(Rect *A, Rect *B) // AABB (Axis-Aligned Bounding Box) overlap implementation
{
	bool horizontal_overlap = Rect_get_left(A) < Rect_get_right(B) && Rect_get_right(A) > Rect_get_left(B);
	bool vertical_overlap = Rect_get_top(A) < Rect_get_bottom(B) && Rect_get_bottom(A) > Rect_get_top(B);
	bool collision = horizontal_overlap && vertical_overlap;
	return collision;
}
