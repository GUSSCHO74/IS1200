#pragma once

#include <stdbool.h>
#include "bitmaps.h"
#include "Display.h"
#include "FrameTimer.h"
#include "helper.h"
#include "IO.h"
#include "Rect.h"
#include "Vector2.h"

#define PLAYER_MAX_BULLETS 32
#define PLAYER_MAX_SMOKE_PARTICLES 64

typedef enum
{
	DIRECTION_LEFT,
	DIRECTION_RIGHT
} Direction;

typedef struct
{
	Vector2f position, velocity;
} Particle;

typedef struct
{
	int8_t health;
	Rect hitbox;
	bool *jetpack, *shoot;
	float vertical_velocity;
	bool on_ground, on_ceiling;
	Direction direction;

	float bullet_speed;
	uint8_t bullet_count;
	Particle bullets[PLAYER_MAX_BULLETS];

	uint8_t smoke_particle_period_index; // used when determining smoke particle initial velocity
	uint8_t smoke_particle_count;
	Particle smoke_particles[PLAYER_MAX_SMOKE_PARTICLES];

	bool has_killed_opponent;

	FrameTimer shoot_timer;
	FrameTimer invincibility_timer;
	FrameTimer death_timer;
} Player;

Player Player_constructor(Vector2f spawn, Vector2f size, bool *jetpack, bool *shoot, Direction direction,
                          int health, float bullet_speed, int shoot_delay_frames, int invincibility_frames);

bool Player_shoot_allowed(Player *player);
bool Player_is_invincible(Player *player);
bool Player_is_dead      (Player *player);
bool Player_is_exploding (Player *player);

Vector2f Player_get_center(Player *player);

void Player_handle_movement(Player *player, Rect *playable_area);
void Player_handle_shooting(Player *player);

void Player_hit            (Player *player);
void Player_start_exploding(Player *player);

void Player_add_bullet           (Player *player);
void Player_add_smoke_particle   (Player *player);
void Player_remove_bullet        (Player *player, uint8_t index);
void Player_remove_smoke_particle(Player *player, uint8_t index);
void Player_update_particles     (Player *player, Rect *playable_area);
void Player_update               (Player *player, Rect *playable_area);

void Player_draw_particles(Player *player, Display *display);
void Player_draw          (Player *player, Display *display, const uint8_t *skin, bool crown, bool show_hitbox);

void Player_handle_opponent(Player *player, Player *opponent);
