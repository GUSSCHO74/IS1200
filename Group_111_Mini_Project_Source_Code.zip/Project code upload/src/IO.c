#include "helper.h"
#include "IO.h"
#include "LED.h"

IO IO_construct()
{
	IO io;

	io.BTN1_last_frame = false;
	io.BTN2_last_frame = false;
	io.BTN3_last_frame = false;
	io.BTN4_last_frame = false;

	return io;
}

/*
	saves the state of the buttons and switches pressed during a frame
*/
void IO_update_inputs(IO *io)
{
	// SW1 (RD8, 8th digit of port D)
	io->SW1 = get_bit(PORTD, 8);
	// SW2 (RD9, 9th digit of port D)
	io->SW2 = get_bit(PORTD, 9);
	// SW3 (RD10, 10th digit of port D)
	io->SW3 = get_bit(PORTD, 10);
	// SW4 (RD11, 11th digit of port D)
	io->SW4 = get_bit(PORTD, 11);

	// BTN1 (RF1, 1st digit of port F)
	io->BTN1 = get_bit(PORTF, 1);
	// BTN2 (RD5, 5th digit of port D)
	io->BTN2 = get_bit(PORTD, 5);
	// BTN3 (RD6, 6th digit of port D)
	io->BTN3 = get_bit(PORTD, 6);
	// BTN4 (RD7, 7th digit of port D)
	io->BTN4 = get_bit(PORTD, 7);

	io->BTN1_pressed_this_frame = io->BTN1 && !io->BTN1_last_frame;
	io->BTN2_pressed_this_frame = io->BTN2 && !io->BTN2_last_frame;
	io->BTN3_pressed_this_frame = io->BTN3 && !io->BTN3_last_frame;
	io->BTN4_pressed_this_frame = io->BTN4 && !io->BTN4_last_frame;

	io->BTN1_last_frame = io->BTN1;
	io->BTN2_last_frame = io->BTN2;
	io->BTN3_last_frame = io->BTN3;
	io->BTN4_last_frame = io->BTN4;
}

/*
	updates the LEDs
*/
void IO_update_outputs(IO *io)
{
	set_LED(0, io->BTN1);
	set_LED(1, io->BTN2);
	set_LED(2, io->BTN3);
	set_LED(3, io->BTN4);
	set_LED(4, io->SW1);
	set_LED(5, io->SW2);
	set_LED(6, io->SW3);
	set_LED(7, io->SW4);
}
