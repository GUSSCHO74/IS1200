#pragma once

#include <stdbool.h>
#include "Vector2.h"

typedef struct
{
	Vector2f position;
	Vector2f size;
} Rect;

Rect Rect_construct(Vector2f position, Vector2f size);

float Rect_get_top   (Rect *rect);
float Rect_get_bottom(Rect *rect);
float Rect_get_left  (Rect *rect);
float Rect_get_right (Rect *rect);

void Rect_set_top   (Rect *rect, float top);
void Rect_set_bottom(Rect *rect, float bottom);
void Rect_set_left  (Rect *rect, float left);
void Rect_set_right (Rect *rect, float right);

bool Rect_contains(Rect *rect, Vector2f point);
bool Rect_overlap(Rect *A, Rect *B);
