#pragma once

#include <stdarg.h>
#include <stdint.h>

/*
	string + int = strint
	string + combo = strombo
*/

#define STRINT_SIZE 7 // to be able to store -65536 and the like, 1 '-' + 5 digits + 1 '\0'
#define STROMBO_SIZE 32

extern char strint[STRINT_SIZE];
extern char strombo[STROMBO_SIZE];

void int_to_string(int num);
void combo_string(const char *str1, const char *str2);
void multi_combo_string(uint8_t argc, ...);
