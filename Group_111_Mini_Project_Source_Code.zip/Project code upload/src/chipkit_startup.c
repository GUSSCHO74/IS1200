// Non-Maskable Interrupt; something bad likely happened, so hang
void _nmi_handler()
{
	for(;;);
}

// Called upon reset
void _on_reset()
{
}

// Called before main()
void _on_bootstrap()
{
}
