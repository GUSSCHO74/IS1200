#include <stdbool.h>
#include <string.h>
#include "int_utils.h"
#include "string_utils.h"

char strint[STRINT_SIZE];
char strombo[STROMBO_SIZE];
char tmp_strombo[STROMBO_SIZE]; // only used when populating strombo, this is so you can combine old strombos into new ones

/*
	stores an integer as a string in the global strint
*/
void int_to_string(int num)
{
	bool negative = false;
	if (num < 0)
	{
		num = -num;
		negative = true;
	}

	uint8_t digit_count = int_digit_count(num);

	uint8_t i;
	for (i = 0; i < digit_count; i++)
	{
		int current_digit_value = int_pow(10, digit_count - 1 - i);
		uint8_t current_digit = num / current_digit_value;
		num -= current_digit * current_digit_value;
		char current_char = (char)(current_digit + '0');
		strint[negative + i] = current_char;
	}

	if (negative)
	{
		num = -num;
		strint[0] = '-';
	}

	strint[negative + digit_count] = '\0'; // null terminator
}

/*
	combines two strings and stores that in the global strombo
*/
void combo_string(const char *str1, const char *str2)
{
	uint8_t str1_size = strlen(str1);
	uint8_t str2_size = strlen(str2);

	uint8_t i, added = 0;
	for (i = 0; i < str1_size; i++)
	{
		tmp_strombo[i] = str1[i];
		added++;
		if (added == STROMBO_SIZE - 1) goto END;
	}
	for (i = 0; i < str2_size; i++)
	{
		tmp_strombo[str1_size + i] = str2[i];
		added++;
		if (added == STROMBO_SIZE - 1) goto END;
	}

END:
	tmp_strombo[added] = '\0';

	uint8_t char_count = strlen(tmp_strombo);
	for (i = 0; i < strlen(tmp_strombo); i++)
	{
		strombo[i] = tmp_strombo[i];
	}
	strombo[strlen(tmp_strombo)] = '\0'; // can't forget the null character
}

/*
	combines several strings and stores in the global strombo
*/
void multi_combo_string(uint8_t argc, ...)
{
	if (argc == 0) return;

	va_list args;
	va_start(args, argc);

	tmp_strombo[0] = '\0'; // "clearing" tmp_strombo

	int i;
	for (i = 0; i < argc; i++)
	{
		char *current_str = va_arg(args, char *);
		combo_string(tmp_strombo, current_str);
	}

	va_end(args);
}
