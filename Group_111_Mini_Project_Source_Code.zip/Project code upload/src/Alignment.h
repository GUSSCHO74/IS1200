#pragma once

#include "Vector2.h"

typedef enum
{
	ALIGN_START,
	ALIGN_CENTER,
	ALIGN_STOP
} Alignment;

Vector2f align(Vector2f position, Vector2f size, Alignment align_x, Alignment align_y);
