#include "FrameTimer.h"

/*
	this can be used to keep track of how many frames have passed
*/

FrameTimer FrameTimer_construct(int frames, int delay_between_frames, bool on)
{
	FrameTimer ft;

	ft.time                 = 0;
	ft.frames               = frames;
	ft.delay_time           = 0;
	ft.delay_between_frames = delay_between_frames;
	ft.on                   = on;

	return ft;
}

void FrameTimer_start(FrameTimer *ft)
{
	ft->on = true;
}

void FrameTimer_stop(FrameTimer *ft)
{
	ft->on = false;
}

void FrameTimer_update(FrameTimer *ft)
{
	if (!ft->on) return;

	if (ft->time < ft->frames)
	{
		if (ft->delay_time == ft->delay_between_frames)
		{
			ft->delay_time = 0;
			ft->time++;
		}
		else
		{
			ft->delay_time++;
		}
	}
}

void FrameTimer_reset(FrameTimer *ft)
{
	ft->time = 0;
	ft->delay_time = 0;
}

bool FrameTimer_is_on(FrameTimer *ft)
{
	return ft->on;
}

bool FrameTimer_is_done(FrameTimer *ft)
{
	return ft->time == ft->frames;
}

// returns true if the timer resets on current iteration, else it returns false
bool FrameTimer_update_and_reset_if_done(FrameTimer *ft, bool stop_if_done)
{
	FrameTimer_update(ft);
	{
		if (FrameTimer_is_done(ft))
		{
			FrameTimer_reset(ft);
			if (stop_if_done)
			{
				FrameTimer_stop(ft);
			}

			return true;
		}
	}

	return false;
}
