#include <stddef.h> // NULL
#include "Settings.h"

void Settings_reset(Settings *settings)
{
	settings->health               = SETTINGS_DEFAULT_HEALTH;
	settings->bullet_speed         = SETTINGS_DEFAULT_BULLET_SPEED;
	settings->shoot_delay_frames   = SETTINGS_DEFAULT_SHOOT_DELAY_FRAMES;
	settings->invincibility_frames = SETTINGS_DEFAULT_INVINCIBILITY_FRAMES;
}

void Settings_change_setting(Settings *settings, uint8_t setting_index, int delta)
{
	uint8_t *setting = NULL;

	switch (setting_index)
	{
		case 0: setting = &settings->health;               break;
		case 1: setting = &settings->bullet_speed;         break;
		case 2: setting = &settings->shoot_delay_frames;   break;
		case 3: setting = &settings->invincibility_frames; break;
		default: return; // no match found, returning to guard against NULL pointersS
	}

	*setting += delta;

	if (*setting > SETTINGS_MAX)
	{
		*setting %= SETTINGS_MAX;
	}
	else if (*setting < SETTINGS_MIN)
	{
		*setting = SETTINGS_MAX - (*setting % SETTINGS_MAX);
	}
}
