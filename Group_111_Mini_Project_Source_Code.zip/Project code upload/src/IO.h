#pragma once

#include <stdbool.h>

typedef struct
{
	// Slide switches
	bool SW1, SW2, SW3, SW4;
	// Pushbuttons
	bool BTN1, BTN2, BTN3, BTN4;
	bool BTN1_last_frame, BTN1_pressed_this_frame;
	bool BTN2_last_frame, BTN2_pressed_this_frame;
	bool BTN3_last_frame, BTN3_pressed_this_frame;
	bool BTN4_last_frame, BTN4_pressed_this_frame;
} IO;

IO IO_construct();
void IO_update_inputs(IO *io);
void IO_update_outputs(IO *io);
