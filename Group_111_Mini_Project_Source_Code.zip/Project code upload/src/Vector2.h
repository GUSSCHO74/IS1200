#pragma once

typedef struct
{
	int x, y;
} Vector2i;

typedef struct
{
	float x, y;
} Vector2f;
