#include "helper.h"

bool get_bit(unsigned int bits, uint8_t index)
{
	return (bits >> index) & 0b1;
}

void toggle(bool *boolean)
{
	*boolean = !(*boolean);
}

/*
	return the absolute value of a float
*/
float absf(float f)
{
	if (f < 0) f *= -1;
	return f;
}
