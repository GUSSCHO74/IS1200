#pragma once

#include <stdint.h>

int int_pow(int num, uint8_t exponent);
uint8_t int_digit_count(int num);
