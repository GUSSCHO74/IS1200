#pragma once

#include <stdbool.h>
#include "Animation.h"
#include "Display.h"
#include "FrameTimer.h"
#include "IO.h"
#include "Player.h"
#include "Rect.h"
#include "Settings.h"

typedef enum
{
	STATE_TITLE_SCREEN,
	STATE_MAIN_MENU,
	STATE_DIFFICULTY,
	STATE_MATCH,
	STATE_SETTINGS
} State;

typedef enum
{
	RESULT_NULL,
	RESULT_DRAW,
	RESULT_PLAYER1_WON,
	RESULT_PLAYER2_WON
} Result;

typedef enum
{
	ROBOT_DIFFICULTY_EASY,
	ROBOT_DIFFICULTY_HARD
} RobotDifficulty;

typedef struct
{
	IO io;
	Display display;
	State state;
	Result result;
	Settings settings;

	bool running;

	bool debug_mode;

	bool player1_god_mode, player2_god_mode;

	int menu_selected_index;

	Player player1, player2;

	bool player1_alt_skin, player2_alt_skin;

	RobotDifficulty robot_difficulty;
	bool robot_jetpack, robot_shoot;
	// these dictate how many frames the robot should wait until performing another action
	FrameTimer robot_jetpack_sleep_timer, robot_shoot_sleep_timer;

	bool current_match_against_robot, last_match_against_robot;

	Vector2f size_of_player;

	Vector2f player1_menu_position, player2_menu_position;

	Rect border, inside_border_area;

	FrameTimer title_screen_timer;
	FrameTimer match_begin_timer;
	FrameTimer match_end_timer;
} Game;

Game Game_construct();
void Game_update(Game *game);
void Game_draw  (Game *game);

void Game_draw_player_hearts(Game *game);

void Game_increment_menu_selection(Game *game, int cap);
void Game_change_state            (Game *game, State new_state);
void Game_prepare_match           (Game *game);
bool Game_display_player_crown    (Game *game, bool player1);

void Game_robot_jetpack_sleep(Game *game, unsigned int frames);
void Game_robot_shoot_sleep(Game *game, unsigned int frames);
void Game_handle_robot(Game *game);
