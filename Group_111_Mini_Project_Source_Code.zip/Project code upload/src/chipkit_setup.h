#pragma once

// IFS stands for Interrupt Flag Status
#define T2_IFS_MASK 0x0100 // 0000 0001 0000 0000, bit  8
#define T3_IFS_MASK 0x1000 // 0001 0000 0000 0000, bit 12

void SPI_init();
void OLED_init();
void chipkit_setup();
