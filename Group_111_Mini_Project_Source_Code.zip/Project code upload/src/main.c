#include <pic32mx.h>
#include "chipkit_setup.h"
#include "Game.h"

int main()
{
	chipkit_setup();

	Game game = Game_construct();

	while (game.running)
	{
		if (IFS(0) & T2_IFS_MASK)
		{
			IFSCLR(0) = T2_IFS_MASK;
			Game_update(&game);
			Game_draw(&game);
		}
	}

	return 0;
}
