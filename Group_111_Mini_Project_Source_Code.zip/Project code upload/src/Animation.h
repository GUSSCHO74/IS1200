#pragma once

#include <stdint.h>

typedef struct
{
	const uint8_t *bitmap;
	uint8_t bitmap_width;
	uint8_t bitmap_height;
	uint8_t frame_size;
} Animation;

Animation Animation_construct(const uint8_t *bitmap, uint8_t frames);
