#include "bitmaps.h"
#include "helper.h"

uint8_t bitmap_get_width(const uint8_t *bitmap)
{
	return bitmap[0];
}

uint8_t bitmap_get_height(const uint8_t *bitmap)
{
	return bitmap[1];
}

bool bitmap_get_bit(const uint8_t *bitmap, uint8_t x, uint8_t y)
{
	uint8_t width = bitmap_get_width(bitmap);
	uint8_t height = bitmap_get_height(bitmap);

	if (x < 0 || x >= width || y < 0 || y >= height) return 0;

	int bit_position = width * y + x;

	int map_index = 2 + bit_position / 8; // THIS NEED TO BE AN BIGGER THAN 8 BITS FOR OUR FONT, AND EVEN BIGGER IMAGES
	uint8_t byte_index = 7 - bit_position % 8;

	return get_bit(bitmap[map_index], byte_index);
}

uint8_t bitmap_font_string_get_width(uint8_t char_count, int8_t char_spacing)
{
	return FONTSIZE + (FONTSIZE + char_spacing) * (char_count - 1);
}
