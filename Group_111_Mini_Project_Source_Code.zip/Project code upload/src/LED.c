#include "helper.h"
#include "LED.h"

bool get_LED(uint8_t index)
{
	return get_bit(LED_PORT, index);
}

void set_LED(uint8_t index, bool bit)
{
	/*
	Example: index = 4, bit = b, LED_PORT = xxxx xxxx
	mask = 0b1       -> 0000 0001 (mask)
	mask <<= 4       -> 0001 0000 (mask)
	mask = ~mask     -> 1110 1111 (mask)
	LED_PORT &= mask -> xxx0 xxxx (LED_PORT)

	bit_8 = (uint8_t)bit -> 0000 000b (bit_8)
	bit_8 <<= 4          -> 000b 0000 (bit_8)
	LED_PORT |= bit_8    -> xxxb xxxx (LED_PORT)
	*/

	uint8_t mask = 0b1;
	mask <<= index;
	mask = ~mask;
	LED_PORT &= mask;

	uint8_t bit_8 = (uint8_t)bit;
	bit_8 <<= index;
	LED_PORT |= bit_8;
}
