#pragma once

#include <stdbool.h>

#define FrameTimer_ON  1
#define FrameTimer_OFF 0

typedef struct
{
	int time, frames, delay_time, delay_between_frames;
	bool on;
} FrameTimer;

FrameTimer FrameTimer_construct(int frames, int delay_between_frames, bool on);
void FrameTimer_start  (FrameTimer *ft);
void FrameTimer_stop   (FrameTimer *ft);
void FrameTimer_update (FrameTimer *ft);
void FrameTimer_reset  (FrameTimer *ft);
bool FrameTimer_is_on  (FrameTimer *ft);
bool FrameTimer_is_done(FrameTimer *ft);
bool FrameTimer_update_and_reset_if_done(FrameTimer *ft, bool stop_if_done);
