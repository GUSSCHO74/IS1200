#include "Display.h"
#include "Player.h"

#define GRAVITY 0.1
#define JETPACK_ACCELERATION 0.4

#define SMOKE_PARTICLES_FROM_JETPACK 3
#define SMOKE_PARTICLE_PERIOD 7
#define SMOKE_PARTICLE_SPREAD 0.1
#define SMOKE_PARTICLE_FALL_SPEED 1

#define INVINCIBILITY_BLINK_FREQUENCY 3

#define DEATH_FRAMES 6
#define DEATH_DELAY_BETWEEN_FRAMES 5

Player Player_constructor(Vector2f spawn, Vector2f size, bool *jetpack, bool *shoot, Direction direction,
                          int health, float bullet_speed, int shoot_delay_frames, int invincibility_frames)
{
	Player player;

	player.health = health;

	player.hitbox.position = spawn;
	player.hitbox.size     = size;
	player.jetpack         = jetpack;
	player.shoot           = shoot;
	player.direction       = direction;
	player.bullet_speed    = bullet_speed;

	player.vertical_velocity = 0;
	player.bullet_count      = 0;

	player.smoke_particle_period_index = 0;
	player.smoke_particle_count        = 0;

	player.has_killed_opponent = false;

	player.shoot_timer         = FrameTimer_construct(shoot_delay_frames, 0, FrameTimer_OFF);
	player.invincibility_timer = FrameTimer_construct(invincibility_frames, 0, FrameTimer_OFF);
	player.death_timer         = FrameTimer_construct(DEATH_FRAMES, DEATH_DELAY_BETWEEN_FRAMES, FrameTimer_OFF);

	return player;
}

bool Player_shoot_allowed(Player *player)
{
	return !player->has_killed_opponent && !FrameTimer_is_on(&player->shoot_timer);
}

bool Player_is_invincible(Player *player)
{
	return FrameTimer_is_on(&player->invincibility_timer);
}

bool Player_is_dead(Player *player)
{
	return player->health == 0;
}

bool Player_is_exploding(Player *player)
{
	return Player_is_dead(player) && FrameTimer_is_on(&player->death_timer) && !FrameTimer_is_done(&player->death_timer);
}

Vector2f Player_get_center(Player *player)
{
	return (Vector2f){
		player->hitbox.position.x + player->hitbox.size.x / 2.f,
		player->hitbox.position.y + player->hitbox.size.y / 2.f
	};
}

/*
	handles all the logic for movement for a specified player
*/
void Player_handle_movement(Player *player, Rect *playable_area)
{
	bool jetpack = *player->jetpack;

	player->vertical_velocity += GRAVITY;

	if (jetpack)
	{
		player->vertical_velocity -= JETPACK_ACCELERATION;
		uint8_t i;
		for (i = 0; i < SMOKE_PARTICLES_FROM_JETPACK; i++)
			Player_add_smoke_particle(player);
	}

	player->hitbox.position.y += player->vertical_velocity;

	player->on_ceiling = false;
	player->on_ground  = false;

	if (Rect_get_top(&player->hitbox) < Rect_get_top(playable_area)) // ceiling
	{
		Rect_set_top(&player->hitbox, Rect_get_top(playable_area));
		player->vertical_velocity = 0;
		player->on_ceiling = true;
	}

	if (Rect_get_bottom(&player->hitbox) > Rect_get_bottom(playable_area)) // ground
	{
		Rect_set_bottom(&player->hitbox, Rect_get_bottom(playable_area));
		player->vertical_velocity = 0;
		player->on_ground = true;
	}
}

/*
	handles all the logic for shooting for a specified player
*/
void Player_handle_shooting(Player *player)
{
	bool shoot = *player->shoot;

	if (Player_shoot_allowed(player))
	{
		if (shoot)
		{
			Player_add_bullet(player);
			FrameTimer_start(&player->shoot_timer);
		}
	}
	else
	{
		FrameTimer_update_and_reset_if_done(&player->shoot_timer, true);
	}
}

void Player_hit(Player *player)
{
	player->health--;
	FrameTimer_start(&player->invincibility_timer);
}

void Player_start_exploding(Player *player)
{
	FrameTimer_start(&player->death_timer);
}

/*
	spawns a new bullet out the players gun
*/
void Player_add_bullet(Player *player)
{
	if (player->bullet_count == PLAYER_MAX_BULLETS) return;

	Particle bullet;

	bullet.position.y = player->hitbox.position.y + 3;
	bullet.velocity.y = 0;

	if (player->direction == DIRECTION_LEFT)
	{
		bullet.position.x = Rect_get_left(&player->hitbox) - 1;
		bullet.velocity.x = -player->bullet_speed;
	}
	else // right
	{
		bullet.position.x = Rect_get_right(&player->hitbox);
		bullet.velocity.x = player->bullet_speed;
	}

	player->bullets[player->bullet_count] = bullet;
	player->bullet_count++;
}

/*
	spawns a new smoke particle out the players jetpack
*/
void Player_add_smoke_particle(Player *player)
{
	if (player->smoke_particle_count == PLAYER_MAX_SMOKE_PARTICLES) return;

	Particle smoke_particle;

	float particle_spread_shift_from_center = player->smoke_particle_period_index + 0.5 - SMOKE_PARTICLE_PERIOD / 2.f;

	if (player->direction == DIRECTION_LEFT)
	{
		smoke_particle.position.x = Rect_get_right(&player->hitbox) - 2;
		smoke_particle.velocity.x = -SMOKE_PARTICLE_SPREAD * particle_spread_shift_from_center;
	}
	else // right
	{
		smoke_particle.position.x = Rect_get_left(&player->hitbox) + 1;
		smoke_particle.velocity.x = SMOKE_PARTICLE_SPREAD * particle_spread_shift_from_center;
	}
	smoke_particle.position.y = Rect_get_bottom(&player->hitbox) - 1;

	player->smoke_particle_period_index++;
	if (player->smoke_particle_period_index >= SMOKE_PARTICLE_PERIOD)
		player->smoke_particle_period_index = 0;

	smoke_particle.velocity.y = SMOKE_PARTICLE_FALL_SPEED;

	player->smoke_particles[player->smoke_particle_count] = smoke_particle;
	player->smoke_particle_count++;
}

/*
	removes a bullet at a given index
*/
void Player_remove_bullet(Player *player, uint8_t index)
{
	if (player->bullet_count == 0) return;

	int i;
	for (i = index; i < player->bullet_count - 1; i++)
	{
		player->bullets[i] = player->bullets[i + 1];
	}
	player->bullet_count--;
}

/*
	removes a smoke particle at a given index
*/
void Player_remove_smoke_particle(Player *player, uint8_t index)
{
	if (player->smoke_particle_count == 0) return;

	int i;
	for (i = index; i < player->smoke_particle_count - 1; i++)
	{
		player->smoke_particles[i] = player->smoke_particles[i + 1];
	}
	player->smoke_particle_count--;
}

/*
	updates all the smoke particles which include all the bullets and smoke particles
*/
void Player_update_particles(Player *player, Rect *playable_area)
{
	int i;

	// bullets
	for (i = 0; i < player->bullet_count; i++)
	{
		Particle *bullet = &player->bullets[i];
		bullet->position.x += bullet->velocity.x;
		bullet->position.y += bullet->velocity.y;

		// removing bullets if they go off screen
		if (!Rect_contains(playable_area, bullet->position))
		{
			Player_remove_bullet(player, i);
			i--;
		}
	}

	// smoke particles
	for (i = 0; i < player->smoke_particle_count; i++)
	{
		Particle *smoke_particle = &player->smoke_particles[i];
		smoke_particle->position.x += smoke_particle->velocity.x;
		smoke_particle->position.y += smoke_particle->velocity.y;

		// removing smoke particles if they go off screen
		if (!Rect_contains(playable_area, smoke_particle->position))
		{
			Player_remove_smoke_particle(player, i);
			i--;
		}
	}
}

/*
	updating everything that needs to be updated for a player during a frame
*/
void Player_update(Player *player, Rect *playable_area)
{
	if (Player_is_dead(player))
	{
		FrameTimer_update(&player->death_timer);
	}
	else
	{
		Player_handle_movement(player, playable_area);
		Player_handle_shooting(player);

		if (Player_is_invincible(player))
		{
			FrameTimer_update_and_reset_if_done(&player->invincibility_timer, true);
		}
	}

	Player_update_particles(player, playable_area);
}

/*
	drawing all the particles, which include bullets and smoke
*/
void Player_draw_particles(Player *player, Display *display)
{
	int i;

	// bullets
	for (i = 0; i < player->bullet_count; i++)
	{
		Display_put_pixel(display, player->bullets[i].position.x, player->bullets[i].position.y, PIXEL_ON);
	}

	// smoke partilces
	for (i = 0; i < player->smoke_particle_count; i++)
	{
		Display_put_pixel(display, player->smoke_particles[i].position.x, player->smoke_particles[i].position.y, PIXEL_ON);
	}
}

/*
	draws an animation if the player is dead, otherwise just draws the player
*/
void Player_draw(Player *player, Display *display, const uint8_t *skin, bool crown, bool show_hitbox)
{
	if (Player_is_dead(player))
	{
		if (!FrameTimer_is_done(&player->death_timer))
		{
			Vector2f death_position = align(Player_get_center(player), (Vector2f){DEATHSIZE, DEATHSIZE}, ALIGN_CENTER, ALIGN_CENTER);
			Display_draw_animation(display, bitmap_death_animation, DEATHSIZE, player->death_timer.time, death_position, FLIP_OFF, PIXEL_ON);
		}
	}
	else
	{
		if (!Player_is_invincible(player) || player->invincibility_timer.time % INVINCIBILITY_BLINK_FREQUENCY == 0)
		{
			if (show_hitbox)
			{
				Rect hitbox_rect = Rect_construct(player->hitbox.position, player->hitbox.size);
				Display_draw_rect(display, hitbox_rect, HOLLOW_OFF, PIXEL_ON);
			}

			Display_draw_bitmap(display, skin, player->hitbox.position, player->direction == DIRECTION_LEFT, !show_hitbox);

			if (crown)
			{
				if (player->direction == DIRECTION_LEFT)
				{
					Display_draw_bitmap(display, bitmap_crown, (Vector2f){player->hitbox.position.x + 4, player->hitbox.position.y - 2}, FLIP_OFF, PIXEL_ON);
				}
				else // right
				{
					Display_draw_bitmap(display, bitmap_crown, (Vector2f){player->hitbox.position.x + 3, player->hitbox.position.y - 2}, FLIP_OFF, PIXEL_ON);
				}
			}
		}
	}

	Player_draw_particles(player, display);
}

/*
	loops through each bullet the player has fired and checks if any have hit the opponent,
	if so decreases the opponents health and removes the bullet
*/
void Player_handle_opponent(Player *player, Player *opponent)
{
	if (Player_is_dead(opponent) || Player_is_invincible(opponent)) return;

	int i;
	for (i = 0; i < player->bullet_count; i++)
	{
		Particle bullet = player->bullets[i];

		if (Rect_contains(&opponent->hitbox, bullet.position))
		{
			Player_hit(opponent);
			Player_remove_bullet(player, i);
			i--;
		}

		if (Player_is_dead(opponent))
		{
			Player_start_exploding(opponent);
			player->has_killed_opponent = true;
			break;
		}
	}
}
