#include <string.h>
#include "bitmaps.h"
#include "Game.h"
#include "helper.h"
#include "string_utils.h"

#define TITLE_SCREEN_FRAMES (FPS * 5)

#define MENU_ITEMS_MAIN_MENU 3
#define MENU_ITEMS_SETTINGS 4
#define MENU_ITEMS_DIFFICULTY 2

#define MATCH_BEGIN_FRAMES 3
#define MATCH_BEGIN_DELAY_BETWEEN_FRAMES FPS
#define MATCH_END_FRAMES (FPS * 2)

#define PLAYER_POSITION_FROM_WALL_DURING_MATCH 26

/*
	important game initialization stuff
*/
Game Game_construct()
{
	Game game;

	game.io = IO_construct();

	game.display.char_spacing = 1;

	game.state = STATE_TITLE_SCREEN;
	game.result = RESULT_NULL;

	game.running = true;

	game.menu_selected_index = 0;

	game.border = Rect_construct((Vector2f){0, 0}, (Vector2f){DISPLAY_SIZE_X, DISPLAY_SIZE_Y});
	game.inside_border_area = Rect_construct((Vector2f){1, 1}, (Vector2f){DISPLAY_SIZE_X - 2, DISPLAY_SIZE_Y - 2});

	game.player1_alt_skin = false;
	game.player2_alt_skin = false;

	game.current_match_against_robot = false;
	game.last_match_against_robot    = false;

	// since the size of the players never change we can store it in this and avoid the same function calls multiple times
	game.size_of_player = (Vector2f){bitmap_get_width(bitmap_player), bitmap_get_height(bitmap_player)};

	game.player1_menu_position = align((Vector2f){DISPLAY_SIZE_X * 0.15, DISPLAY_SIZE_Y * 0.50}, game.size_of_player, ALIGN_CENTER, ALIGN_CENTER);
	game.player2_menu_position = align((Vector2f){DISPLAY_SIZE_X * 0.85, DISPLAY_SIZE_Y * 0.50}, game.size_of_player, ALIGN_CENTER, ALIGN_CENTER);

	game.title_screen_timer = FrameTimer_construct(TITLE_SCREEN_FRAMES, 0, FrameTimer_ON);
	game.match_begin_timer  = FrameTimer_construct(MATCH_BEGIN_FRAMES, MATCH_BEGIN_DELAY_BETWEEN_FRAMES, FrameTimer_OFF);
	game.match_end_timer    = FrameTimer_construct(MATCH_END_FRAMES, 0, FrameTimer_OFF);

	game.settings.health               = SETTINGS_DEFAULT_HEALTH;
	game.settings.invincibility_frames = SETTINGS_DEFAULT_INVINCIBILITY_FRAMES;
	game.settings.bullet_speed         = SETTINGS_DEFAULT_BULLET_SPEED;
	game.settings.shoot_delay_frames   = SETTINGS_DEFAULT_SHOOT_DELAY_FRAMES;

	return game;
}

/*
	the main update function for the game, this runs every single frame.
*/
void Game_update(Game *game)
{
	IO_update_inputs(&game->io);
	IO_update_outputs(&game->io);

	game->display.inverse  = game->io.SW4;
	game->debug_mode       = game->io.SW3;
	game->player1_god_mode = game->io.SW2;
	game->player2_god_mode = game->io.SW1;

	switch (game->state)
	{
		case STATE_TITLE_SCREEN:
		{
			FrameTimer_update(&game->title_screen_timer);
			bool any_buttons_pressed = game->io.BTN1 || game->io.BTN2 || game->io.BTN3 || game->io.BTN4;
			if (any_buttons_pressed || FrameTimer_is_done(&game->title_screen_timer))
			{
				Game_change_state(game, STATE_MAIN_MENU);
			}
			break;
		}
		case STATE_MAIN_MENU:
		{
			bool change_menu_selection = game->io.BTN4_pressed_this_frame;
			bool select_menu_item      = game->io.BTN3_pressed_this_frame;
			bool change_player1_skin   = game->io.BTN2_pressed_this_frame;
			bool change_player2_skin   = game->io.BTN1_pressed_this_frame;

			if (change_menu_selection)
			{
				Game_increment_menu_selection(game, MENU_ITEMS_MAIN_MENU);
			}

			if (select_menu_item)
			{
				switch (game->menu_selected_index)
				{
					case 0:
					{
						game->current_match_against_robot = true;
						Game_change_state(game, STATE_DIFFICULTY);
						break;
					}
					case 1:
					{
						game->current_match_against_robot = false;
						Game_change_state(game, STATE_MATCH);
						break;
					}
					case 2:
					{
						Game_change_state(game, STATE_SETTINGS);
						break;
					}
				}
			}

			if (change_player1_skin) toggle(&game->player1_alt_skin);
			if (change_player2_skin) toggle(&game->player2_alt_skin);

			break;
		}
		case STATE_DIFFICULTY:
		{
			bool change_menu_selection = game->io.BTN4_pressed_this_frame;
			bool select_menu_item      = game->io.BTN3_pressed_this_frame;

			if (change_menu_selection)
			{
				Game_increment_menu_selection(game, MENU_ITEMS_DIFFICULTY);
			}

			if (select_menu_item)
			{
				switch (game->menu_selected_index)
				{
					case 0: game->robot_difficulty = ROBOT_DIFFICULTY_EASY; break;
					case 1: game->robot_difficulty = ROBOT_DIFFICULTY_HARD; break;
				}
				Game_change_state(game, STATE_MATCH);
			}

			break;
		}
		case STATE_MATCH:
		{
			if (FrameTimer_is_on(&game->match_begin_timer)) // match countdown
			{
				FrameTimer_update_and_reset_if_done(&game->match_begin_timer, true);
			}
			else // gameplay
			{
				if (game->current_match_against_robot)
				{
					Game_handle_robot(game);
				}

				Player_update(&game->player1, &game->inside_border_area);
				Player_update(&game->player2, &game->inside_border_area);

				if (FrameTimer_is_on(&game->match_end_timer)) // match has ended
				{
					if (FrameTimer_update_and_reset_if_done(&game->match_end_timer, true))
					{
						Game_change_state(game, STATE_MAIN_MENU);
					}
				}
				else // player vs player
				{
					Player_handle_opponent(&game->player1, &game->player2);
					Player_handle_opponent(&game->player2, &game->player1);

					if (game->player1_god_mode)
						game->player1.health = game->settings.health;
					if (game->player2_god_mode)
						game->player2.health = game->settings.health;

					bool player1_dead = Player_is_dead(&game->player1);
					bool player2_dead = Player_is_dead(&game->player2);

					bool someone_dead = player1_dead || player2_dead;
					bool no_bullets_left = game->player1.bullet_count == 0 && game->player2.bullet_count == 0;
					bool nobody_exploding = !Player_is_exploding(&game->player1) && !Player_is_exploding(&game->player2);

					if (someone_dead && no_bullets_left && nobody_exploding)
					{
						if (player1_dead && player2_dead) // draw
						{
							game->result = RESULT_DRAW;
						}
						else if (player2_dead) // player 1 wins
						{
							game->result = RESULT_PLAYER1_WON;
						}
						else if (player1_dead) // player 2 wins
						{
							game->result = RESULT_PLAYER2_WON;
						}

						FrameTimer_start(&game->match_end_timer);
					}
				}
			}
			break;
		}
		case STATE_SETTINGS:
		{
			bool change_menu_selection = game->io.BTN4_pressed_this_frame;
			bool save_settings         = game->io.BTN3_pressed_this_frame;
			bool increment_setting     = game->io.BTN2_pressed_this_frame;
			bool decrement_setting     = game->io.BTN1_pressed_this_frame;

			if (change_menu_selection)
			{
				Game_increment_menu_selection(game, MENU_ITEMS_SETTINGS);
			}

			if (game->io.BTN2 && game->io.BTN1)
			{
				Settings_reset(&game->settings);
			}
			else if (increment_setting)
			{
				Settings_change_setting(&game->settings, game->menu_selected_index, +1);
			}
			else if (decrement_setting)
			{
				Settings_change_setting(&game->settings, game->menu_selected_index, -1);
			}

			if (save_settings)
			{
				Game_change_state(game, STATE_MAIN_MENU);
			}

			break;
		}
	}
}

/*
	the main draw function for the game, this runs every single frame.
	draws all the stuff seen on screen. graphics.
*/
void Game_draw(Game *game)
{
	Display_clear(&game->display);

	Display_draw_rect(&game->display, game->border, HOLLOW_ON, PIXEL_ON);

	switch (game->state)
	{
		case STATE_TITLE_SCREEN:
		{
			Display_draw_bitmap(&game->display, bitmap_title_screen, (Vector2f){1, 1}, FLIP_OFF, PIXEL_ON);
			break;
		}
		case STATE_MAIN_MENU:
		{
			Display_draw_string(&game->display, "1 Player", (Vector2f){DISPLAY_SIZE_X / 2, 4 + 9 * 0}, ALIGN_CENTER, ALIGN_START, FLIP_OFF, PIXEL_ON, game->menu_selected_index == 0);
			Display_draw_string(&game->display, "2 Player", (Vector2f){DISPLAY_SIZE_X / 2, 4 + 9 * 1}, ALIGN_CENTER, ALIGN_START, FLIP_OFF, PIXEL_ON, game->menu_selected_index == 1);
			Display_draw_string(&game->display, "Settings", (Vector2f){DISPLAY_SIZE_X / 2, 4 + 9 * 2}, ALIGN_CENTER, ALIGN_START, FLIP_OFF, PIXEL_ON, game->menu_selected_index == 2);

			// drawing player 1
			Display_draw_bitmap(&game->display, game->player1_alt_skin ? bitmap_player_alt : bitmap_player, game->player1_menu_position, FLIP_OFF, PIXEL_ON);

			// drawing player 2
			if (game->menu_selected_index == 0) // drawing player 2 as a robot
			{
				Display_draw_bitmap(&game->display, game->player2_alt_skin ? bitmap_robot_alt : bitmap_robot, game->player2_menu_position, FLIP_ON, PIXEL_ON);
			}
			else                                // drawing player 2 as not a robot
			{
				Display_draw_bitmap(&game->display, game->player2_alt_skin ? bitmap_player_alt : bitmap_player, game->player2_menu_position, FLIP_ON, PIXEL_ON);
			}

			if (Game_display_player_crown(game, true))
			{
				Display_draw_bitmap(
					&game->display,
					bitmap_crown,
					(Vector2f){game->player1_menu_position.x + 3, game->player1_menu_position.y - 2},
					FLIP_OFF,
					PIXEL_ON
				);
			}
			else
			if (Game_display_player_crown(game, false))
			{
				Display_draw_bitmap(
					&game->display,
					bitmap_crown,
					(Vector2f){game->player2_menu_position.x + 4, game->player2_menu_position.y - 2},
					FLIP_OFF,
					PIXEL_ON
				);
			}
			break;
		}
		case STATE_DIFFICULTY:
		{
			#define DIFFICULTY_PADDING 4

			Display_draw_string(
				&game->display,
				"-Choose difficulty-",
				(Vector2f){DISPLAY_SIZE_X / 2, DISPLAY_SIZE_Y * 0.33},
				ALIGN_CENTER,
				ALIGN_CENTER,
				FLIP_OFF,
				PIXEL_ON,
				BACKGROUND_OFF
			);
			Display_draw_string(
				&game->display,
				"EASY",
				(Vector2f){DISPLAY_SIZE_X / 2 - DIFFICULTY_PADDING, DISPLAY_SIZE_Y * 0.67},
				ALIGN_STOP,
				ALIGN_CENTER,
				FLIP_OFF,
				PIXEL_ON,
				game->menu_selected_index == 0
			);
			Display_draw_string(
				&game->display,
				"HARD",
				(Vector2f){DISPLAY_SIZE_X / 2 + DIFFICULTY_PADDING, DISPLAY_SIZE_Y * 0.67},
				ALIGN_START,
				ALIGN_CENTER,
				FLIP_OFF,
				PIXEL_ON,
				game->menu_selected_index == 1
			);
			break;
		}
		case STATE_MATCH:
		{
			// draw player 1
			const uint8_t *player1_skin = game->player1_alt_skin ? bitmap_player_alt : bitmap_player;
			Player_draw(
				&game->player1,
				&game->display,
				player1_skin,
				Game_display_player_crown(game, true),
				game->debug_mode
			);
			// draw player 2
			const uint8_t *player2_skin;
			if (game->current_match_against_robot)
			{
				player2_skin = game->player2_alt_skin ? bitmap_robot_alt : bitmap_robot;
			}
			else
			{
				player2_skin = game->player2_alt_skin ? bitmap_player_alt : bitmap_player;
			}
			Player_draw(
				&game->player2,
				&game->display,
				player2_skin,
				Game_display_player_crown(game, false),
				game->debug_mode
			);

			Game_draw_player_hearts(game);

			if (FrameTimer_is_on(&game->match_begin_timer)) // displays a countdown before a match begins
			{
				int_to_string(game->match_begin_timer.frames - game->match_begin_timer.time);
				Display_draw_string(&game->display, strint, DISPLAY_CENTER, ALIGN_CENTER, ALIGN_CENTER, FLIP_OFF, PIXEL_ON, BACKGROUND_OFF);
			}
			else if (FrameTimer_is_on(&game->match_end_timer)) // displays the result after a match has ended
			{
				switch (game->result)
				{
					case RESULT_DRAW:
					{
						Display_draw_string(&game->display, "Nobody won :(", DISPLAY_CENTER, ALIGN_CENTER, ALIGN_CENTER, FLIP_OFF, PIXEL_ON, BACKGROUND_OFF);
						break;
					}
					case RESULT_PLAYER1_WON:
					{
						Display_draw_string(&game->display, "Player 1 won!", DISPLAY_CENTER, ALIGN_CENTER, ALIGN_CENTER, FLIP_OFF, PIXEL_ON, BACKGROUND_OFF);
						break;
					}
					case RESULT_PLAYER2_WON:
					{
						Display_draw_string(&game->display, "Player 2 won!", DISPLAY_CENTER, ALIGN_CENTER, ALIGN_CENTER, FLIP_OFF, PIXEL_ON, BACKGROUND_OFF);
						break;
					}
				}
			}

			if (game->debug_mode) // info useful when debugging
			{
				// player 1: bullet_count | smoke_particle_count in the bottom left corner
				int_to_string(game->player1.bullet_count);
				multi_combo_string(2, strint, "|");
				int_to_string(game->player1.smoke_particle_count);
				multi_combo_string(2, strombo, strint);
				Display_draw_string(&game->display, strombo, (Vector2f){1, DISPLAY_SIZE_Y - 1}, ALIGN_START, ALIGN_STOP, FLIP_OFF, PIXEL_ON, BACKGROUND_ON);
				if (game->player1_god_mode)
				{
					Display_draw_string(&game->display, "God", (Vector2f){1, DISPLAY_SIZE_Y / 2}, ALIGN_START, ALIGN_CENTER, FLIP_OFF, PIXEL_ON, BACKGROUND_ON);
				}

				// player 2: smoke_particle_count | bullet_count in the bottom right corner
				int_to_string(game->player2.smoke_particle_count);
				multi_combo_string(2, strint, "|");
				int_to_string(game->player2.bullet_count);
				multi_combo_string(2, strombo, strint);
				Display_draw_string(&game->display, strombo, (Vector2f){DISPLAY_SIZE_X - 1, DISPLAY_SIZE_Y - 1}, ALIGN_STOP, ALIGN_STOP, FLIP_OFF, PIXEL_ON, BACKGROUND_ON);
				if (game->player2_god_mode)
				{
					Display_draw_string(&game->display, "God", (Vector2f){DISPLAY_SIZE_X - 1, DISPLAY_SIZE_Y / 2}, ALIGN_STOP, ALIGN_CENTER, FLIP_OFF, PIXEL_ON, BACKGROUND_ON);
				}

				if (game->current_match_against_robot)
				{
					Display_draw_string(
						&game->display,
						game->robot_difficulty == ROBOT_DIFFICULTY_EASY ? "Easy" : "Hard",
						(Vector2f){DISPLAY_SIZE_X / 2, DISPLAY_SIZE_Y - 1},
						ALIGN_CENTER,
						ALIGN_STOP,
						FLIP_OFF,
						PIXEL_ON,
						BACKGROUND_ON
					);
				}
			}
			break;
		}
		case STATE_SETTINGS:
		{
			Rect selection_background = Rect_construct((Vector2f){2, 2 + 7 * game->menu_selected_index}, (Vector2f){DISPLAY_SIZE_X - 4, 7});
			Display_draw_rect(&game->display, selection_background, HOLLOW_OFF, PIXEL_ON);

			Display_draw_string(&game->display, "Health"       , (Vector2f){3, 3 + 7 * 0}, ALIGN_START, ALIGN_START, FLIP_OFF, game->menu_selected_index != 0, BACKGROUND_OFF);
			Display_draw_string(&game->display, "Bullet speed" , (Vector2f){3, 3 + 7 * 1}, ALIGN_START, ALIGN_START, FLIP_OFF, game->menu_selected_index != 1, BACKGROUND_OFF);
			Display_draw_string(&game->display, "Shoot delay"  , (Vector2f){3, 3 + 7 * 2}, ALIGN_START, ALIGN_START, FLIP_OFF, game->menu_selected_index != 2, BACKGROUND_OFF);
			Display_draw_string(&game->display, "Invincibility", (Vector2f){3, 3 + 7 * 3}, ALIGN_START, ALIGN_START, FLIP_OFF, game->menu_selected_index != 3, BACKGROUND_OFF);

			int i;
			for (i = 0; i < SETTINGS_MAX; i++)
			{
				const uint8_t *bitmap;
				Vector2f position = { DISPLAY_SIZE_X - 5 - 3 - i * 6, 3 };

				bitmap = i < game->settings.health ? bitmap_heart : bitmap_heart_hollow;
				Display_draw_bitmap(&game->display, bitmap, position, FLIP_OFF, game->menu_selected_index != 0);
				position.y += 7;

				bitmap = i < game->settings.bullet_speed ? bitmap_diamond : bitmap_diamond_hollow;
				Display_draw_bitmap(&game->display, bitmap, position, FLIP_OFF, game->menu_selected_index != 1);
				position.y += 7;

				bitmap = i < game->settings.shoot_delay_frames ? bitmap_diamond : bitmap_diamond_hollow;
				Display_draw_bitmap(&game->display, bitmap, position, FLIP_OFF, game->menu_selected_index != 2);
				position.y += 7;

				bitmap = i < game->settings.invincibility_frames ? bitmap_diamond : bitmap_diamond_hollow;
				Display_draw_bitmap(&game->display, bitmap, position, FLIP_OFF, game->menu_selected_index != 3);
			}

			break;
		}
	}

	Display_update(&game->display);
}

/*
	draws the player hearts during a match
*/
void Game_draw_player_hearts(Game *game)
{
	int i;
	for (i = 0; i < game->settings.health; i++)
	{
		uint8_t x_index = i;
		uint8_t y_position = 2;

		if (i >= 3)
		{
			x_index -= 3;
			y_position += HEARTSIZE + 1;
		}

		uint8_t x_distance_from_wall = x_index * (HEARTSIZE + 1);

		const uint8_t *bitmap;

		// player1 hearts
		bitmap = game->player1.health > i ? bitmap_heart : bitmap_heart_hollow;
		Display_draw_bitmap(&game->display, bitmap, (Vector2f){2 + x_distance_from_wall, y_position}, FLIP_OFF, PIXEL_ON);

		// player2 hearts
		bitmap = game->player2.health > i ? bitmap_heart : bitmap_heart_hollow;
		Display_draw_bitmap(&game->display, bitmap, (Vector2f){DISPLAY_SIZE_X - 2 - HEARTSIZE - x_distance_from_wall, y_position}, FLIP_OFF, PIXEL_ON);
	}
}

/*
	used to traverse our menu system.
	goes only one way and then loops around.
*/
void Game_increment_menu_selection(Game *game, int menu_items)
{
	game->menu_selected_index++;
	if (game->menu_selected_index == menu_items)
		game->menu_selected_index = 0;
}

/*
	used to change the state the game is in and perform different actions
	depending on what the game state was and what it is going to be.
*/
void Game_change_state(Game *game, State new_state)
{
	State last_state = game->state;
	game->state = new_state;

	game->menu_selected_index = 0;

	switch (last_state)
	{
		case STATE_MATCH:
		{
			game->last_match_against_robot = game->current_match_against_robot;
			break;
		}
	}

	switch (new_state)
	{
		case STATE_MATCH:
		{
			Game_prepare_match(game);
			FrameTimer_start(&game->match_begin_timer);
			break;
		}
	}
}

/*
	used before a match to construct each player with the
	correct attributes and controls which depend on whether
	the match is going to be played against a robot or not
*/
void Game_prepare_match(Game *game)
{
	bool *player1_jetpack = &game->io.BTN4;
	bool *player1_shoot   = &game->io.BTN3_pressed_this_frame;

	bool *player2_jetpack, *player2_shoot;

	if (game->current_match_against_robot)
	{
		player2_jetpack = &game->robot_jetpack;
		player2_shoot   = &game->robot_shoot;

		game->robot_jetpack = false;
		game->robot_shoot   = false;
		game->robot_jetpack_sleep_timer.on = false;
		game->robot_shoot_sleep_timer.on   = false;
	}
	else
	{
		player2_jetpack = &game->io.BTN2;
		player2_shoot   = &game->io.BTN1_pressed_this_frame;
	}

	game->player1 = Player_constructor(
		align((Vector2f){PLAYER_POSITION_FROM_WALL_DURING_MATCH, DISPLAY_SIZE_Y - 1}, game->size_of_player, ALIGN_CENTER, ALIGN_STOP),
		game->size_of_player,
		player1_jetpack,
		player1_shoot,
		DIRECTION_RIGHT,
		game->settings.health               * SETTINGS_MULTIPLIER_HEALTH,
		game->settings.bullet_speed         * SETTINGS_MULTIPLIER_BULLET_SPEED,
		game->settings.shoot_delay_frames   * SETTINGS_MULTIPLIER_SHOOT_DELAY_FRAMES,
		game->settings.invincibility_frames * SETTINGS_MULTIPLIER_INVINCIBILITY_FRAMES
	);

	game->player2 = Player_constructor(
		align((Vector2f){DISPLAY_SIZE_X - PLAYER_POSITION_FROM_WALL_DURING_MATCH, DISPLAY_SIZE_Y - 1}, game->size_of_player, ALIGN_CENTER, ALIGN_STOP),
		game->size_of_player,
		player2_jetpack,
		player2_shoot,
		DIRECTION_LEFT,
		game->settings.health               * SETTINGS_MULTIPLIER_HEALTH,
		game->settings.bullet_speed         * SETTINGS_MULTIPLIER_BULLET_SPEED,
		game->settings.shoot_delay_frames   * SETTINGS_MULTIPLIER_SHOOT_DELAY_FRAMES,
		game->settings.invincibility_frames * SETTINGS_MULTIPLIER_INVINCIBILITY_FRAMES
	);
}

/*
	returns a boolean which indicates whether or not to a
	specified player should have a crown above the head or not
*/
bool Game_display_player_crown(Game *game, bool player1)
{
	if (player1 && game->result == RESULT_PLAYER1_WON
	    ||
	   !player1 && game->result == RESULT_PLAYER2_WON)
	{
		switch (game->state)
		{
			case STATE_MAIN_MENU:
			{
				return (game->menu_selected_index == 0) == game->last_match_against_robot;
			}
			case STATE_MATCH:
			{
				if (FrameTimer_is_on(&game->match_end_timer)) // new result has been decided
				{
					return true;
				}
				else // result from old match
				{
					return game->current_match_against_robot == game->last_match_against_robot;
				}
			}
		}
	}

	return false;
}

/*
	used by the robot ai to wait after performing a jetpack action
*/
void Game_robot_jetpack_sleep(Game *game, unsigned int frames)
{
	game->robot_jetpack_sleep_timer = FrameTimer_construct(frames, 0, FrameTimer_ON);
}

/*
	used by the robot ai to wait after performing a shoot action
*/
void Game_robot_shoot_sleep(Game *game, unsigned int frames)
{
	game->robot_shoot_sleep_timer = FrameTimer_construct(frames, 0, FrameTimer_ON);
}

/*
	handles all the stuff for the robot ai

	--- how the ai works (kinda) ---
	the ai is divided into two stages: jetpack and shoot.
	during the jetpack stage the robot will first check if it has detected a bullet and then try to avoid it, otherwise it will just try to follow the player.
	during the shoot stage the robot will just try to shoot at the player.

	--- jetpack (EASY MODE) ---
	if the robot has detected a bullet:
		it will toggle the state of the jetpack.
	else:
		if the player is close to the ground the robot will not use the jetpack,
		and if the player is close to the ceiling the robot will use the jetpack.

	--- jetpack (HARD MODE) ---
	if the robot has detected a bullet:
		it will either use the jetpack if it is close to the ground or not use the jetpack if it is close to the ceiling.
	else:
		if the player is above the robot it will use the jetpack,
		but if the robot is above the player it will not use the jetpack.

	--- shoot (EASY MODE) ---
	if the robots detects the player somewhere in front of itself in the y-axis
	with a shoot detection range of 0 pixels it will shoot and then initiate
	a wait time until another shoot action may be executed
	--- shoot (HARD MODE) ---
	same as EASY MODE but the shoot detection range is bigger
	and the wait time between shoot actions is shorter
*/
void Game_handle_robot(Game *game)
{
	float ceiling = Rect_get_top   (&game->inside_border_area);
	float ground  = Rect_get_bottom(&game->inside_border_area);

	Vector2f player_center = Player_get_center(&game->player1);
	Vector2f robot_center  = Player_get_center(&game->player2);

	float vertical_distance_to_player = player_center.y - robot_center.y;
	bool player_above_robot = vertical_distance_to_player < 0;
	bool robot_above_player = vertical_distance_to_player > 0;

	/*
		we assume that the ceiling position will be less than any player center y-position
		also, that the ground position will be bigger than any player center y-position
		all because we restrict the players between these points
	*/
	float player_distance_to_ceiling = player_center.y - ceiling;
	float player_distance_to_ground  = ground - player_center.y;
	bool player_closest_to_ceiling   = player_distance_to_ceiling < player_distance_to_ground;
	bool player_closest_to_ground    = player_distance_to_ground < player_distance_to_ceiling;

	float robot_distance_to_ceiling = robot_center.y - ceiling;
	float robot_distance_to_ground  = ground - robot_center.y;
	bool robot_closest_to_ceiling   = robot_distance_to_ceiling < robot_distance_to_ground;
	bool robot_closest_to_ground    = robot_distance_to_ground < robot_distance_to_ceiling;

	bool robot_afraid_of_bullet = false;
	int i;
	for (i = 0; i < game->player1.bullet_count; i++)
	{
		Particle current_bullet = game->player1.bullets[i];

		// go to the next bullet if the current bullet is already passed the robot
		if (current_bullet.position.x > Rect_get_right(&game->player2.hitbox)) continue;

		if (current_bullet.position.y > Rect_get_top(&game->player2.hitbox)
		    &&
		    current_bullet.position.y < Rect_get_bottom(&game->player2.hitbox))
		{
			robot_afraid_of_bullet = true;
			break;
		}
	}

	// ROBOT JETPACK
	if (FrameTimer_is_on(&game->robot_jetpack_sleep_timer))
	{
		FrameTimer_update_and_reset_if_done(&game->robot_jetpack_sleep_timer, true);
	}
	else
	{
		if (Player_is_dead(&game->player1) && !robot_afraid_of_bullet)
		{
			game->robot_jetpack = false;
		}
		else
		{
			switch (game->robot_difficulty)
			{
				case ROBOT_DIFFICULTY_EASY:
				{
					if (robot_afraid_of_bullet)
					{
						toggle(&game->robot_jetpack);
					}
					else
					{
						if (player_closest_to_ground)
						{
							game->robot_jetpack = false;
						}
						else if (player_closest_to_ceiling)
						{
							game->robot_jetpack = true;
						}
					}
					Game_robot_jetpack_sleep(game, game->robot_jetpack ? 5 : 10);
					break;
				}
				case ROBOT_DIFFICULTY_HARD:
				{
					if (robot_afraid_of_bullet)
					{
						if (robot_closest_to_ground)
						{
							game->robot_jetpack = true;
							Game_robot_jetpack_sleep(game, 10);
						}
						else if (robot_closest_to_ceiling)
						{
							game->robot_jetpack = false;
							Game_robot_jetpack_sleep(game, 20);
						}
					}
					else
					{
						if (player_above_robot)
						{
							game->robot_jetpack = true;
							Game_robot_jetpack_sleep(game, 3);
						}
						else if (robot_above_player)
						{
							game->robot_jetpack = false;
							Game_robot_jetpack_sleep(game, 6);
						}
					}
					break;
				}
			}
		}
	}

	// ROBOT SHOOT
	game->robot_shoot = false; // this gets reset every update, opposed to the jetpack

	if (FrameTimer_is_on(&game->robot_shoot_sleep_timer))
	{
		FrameTimer_update_and_reset_if_done(&game->robot_shoot_sleep_timer, true);
	}
	else
	{
		#define EASY_ROBOT_SHOOT_MARGIN 0
		#define HARD_ROBOT_SHOOT_MARGIN 5
		#define EASY_ROBOT_SHOOT_WAIT   game->player2.shoot_timer.frames * 3
		#define HARD_ROBOT_SHOOT_WAIT   game->player2.shoot_timer.frames

		switch (game->robot_difficulty)
		{
			case ROBOT_DIFFICULTY_EASY:
			{
				game->robot_shoot = absf(vertical_distance_to_player) < game->size_of_player.y / 2.f + EASY_ROBOT_SHOOT_MARGIN;
				if (game->robot_shoot)
				{
					Game_robot_shoot_sleep(game, EASY_ROBOT_SHOOT_WAIT);
				}
				break;
			}
			case ROBOT_DIFFICULTY_HARD:
			{
				game->robot_shoot = absf(vertical_distance_to_player) < game->size_of_player.y / 2.f + HARD_ROBOT_SHOOT_MARGIN;
				if (game->robot_shoot)
				{
					Game_robot_shoot_sleep(game, HARD_ROBOT_SHOOT_WAIT);
				}
				break;
			}
		}
	}
}
