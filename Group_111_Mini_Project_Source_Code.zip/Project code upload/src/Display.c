#include <pic32mx.h>
#include <string.h>
#include "bitmaps.h"
#include "Display.h"

/*
	The SPI_put_byte, Display_update_row, and Display_update functions were largely
	influenced by the respective functions Spi2PutByte, OledPutBuffer, and OledUpdate
	given as examples in the "chipKIT Basic I/O Shield Reference Manual".
*/

/*
	used to communicate with the display via the Serial Peripheral Interface (SPI)
*/
void SPI_put_byte(uint8_t byte)
{
	// Wait for transmitter to be ready
	while ((SPI2STAT & PIC32_SPISTAT_SPITBE) == 0);
	// Write the next transmit byte
	SPI2BUF = byte;
}

/*
	updates one row of the display (assuming the buffer pointer points to the start of a row in the display).
	used in Display_update.
*/
void Display_update_row(uint8_t *buffer)
{
	int x;
	for (x = 0; x < DISPLAY_SIZE_X; x++)
	{
		// Wait for transmitter to be ready
		while ((SPI2STAT & PIC32_SPISTAT_SPITBE) == 0);
		// Write the next transmit byte.
		SPI2BUF = *buffer++;
	}
}

/*
	updates the whole display.
*/
void Display_update(Display *display)
{
	uint8_t *buffer_copy = display->buffer;

	int row;
	for (row = 0; row < DISPLAY_ROWS; row++)
	{
		OLED_SET_COMMAND_MODE;
		SPI_put_byte(0x22);
		SPI_put_byte(row);
		SPI_put_byte(0x00);
		SPI_put_byte(0x10);
		OLED_SET_DATA_MODE;

		Display_update_row(buffer_copy);
		buffer_copy += DISPLAY_SIZE_X;
	}
}

/*
	clears the whole display. either to completely white or completely black,
	depending on if the display is set to inverse or not
*/
void Display_clear(Display *display)
{
	int i;
	for (i = 0; i < DISPLAY_BUFFER_SIZE; i++) display->buffer[i] = display->inverse ? ~0x0 : 0x0;
}

/*
	draws a pixel on the display at a given x and y coordinate.
	the pixel boolean determines whether to draw a white or black pixel,
	which inverts depending on if the display is inversed or not.

	example (pseudocode):
	if (display_is_inversed)
	{
		if (pixel)
			draw_black_pixel(x, y);
		else
			draw_white_pixel(x, y);
	}
	else
	{
		if (pixel)
			draw_white_pixel(x, y);
		else
			draw_black_pixel(x, y);
	}
*/
void Display_put_pixel(Display *display, int x, int y, bool pixel)
{
	if (x < 0 || x >= DISPLAY_SIZE_X || y < 0 || y >= DISPLAY_SIZE_Y) return;

	int row = y / 8;

	if (display->inverse) pixel = !pixel;

	if (pixel)
	{
		display->buffer[x + DISPLAY_SIZE_X * row] |= 0x1 << (y % 8);
	}
	else
	{
		display->buffer[x + DISPLAY_SIZE_X * row] &= ~(0x1 << (y % 8));
	}
}

/*
	draws a horizontal line with a given length from a given position.
	since the x-axis of the display grows to the right, so does the line.
*/
void Display_draw_horizontal_line(Display *display, Vector2f position, int length, bool pixel)
{
	int i;
	for (i = 0; i < length; i++)
	{
		Display_put_pixel(display, position.x + i, position.y, pixel);
	}
}

/*
	draws a vertical line with a given length from a given position.
	since the y-axis of the display grows to downwards, so does the line.
*/
void Display_draw_vertical_line(Display *display, Vector2f position, int length, bool pixel)
{
	int i;
	for (i = 0; i < length; i++)
	{
		Display_put_pixel(display, position.x, position.y + i, pixel);
	}
}

/*
	draws a rectangle, which can be either hollow (just the border) or filled in.
*/
void Display_draw_rect(Display *display, Rect rect, bool hollow, bool pixel)
{
	if (hollow)
	{
		// top left -> top right
		Display_draw_horizontal_line(display, (Vector2f){rect.position.x, rect.position.y}, rect.size.x, pixel);
		// bottom left -> bottom right
		Display_draw_horizontal_line(display, (Vector2f){rect.position.x, rect.position.y + (rect.size.y - 1)}, rect.size.x, pixel);
		// top left -> bottom left
		Display_draw_vertical_line(display, (Vector2f){rect.position.x, rect.position.y + 1}, rect.size.y - 2, pixel);
		// top right -> bottom right
		Display_draw_vertical_line(display, (Vector2f){rect.position.x + (rect.size.x - 1), rect.position.y + 1}, rect.size.y - 2, pixel);
	}
	else
	{
		int x;
		for (x = 0; x < rect.size.x; x++)
		{
			Display_draw_vertical_line(display, (Vector2f){rect.position.x + x, rect.position.y}, rect.size.y, pixel);
		}
	}
}

/*
	draws a bitmap at a given position. you can also choose to flip the bitmap, which will mirror what is drawn in the x-axis.
*/
void Display_draw_bitmap(Display *display, const uint8_t *bitmap, Vector2f position, bool flip, bool pixel)
{
	uint8_t width = bitmap_get_width(bitmap);
	uint8_t height = bitmap_get_height(bitmap);
	uint8_t x, y;

	if (flip)
	{
		/*
			it is slower to draw flipped since we do not
			access the data in the order it is stored in
		*/
		for (x = 0; x < width; x++)
		{
			for (y = 0; y < height; y++)
			{
				if (bitmap_get_bit(bitmap, width - 1 - x, y))
				{
					Display_put_pixel(display, position.x + x, position.y + y, pixel);
				}
			}
		}
	}
	else
	{
		int current_map_index = 2; // since the first two bytes specift the size
		int current_bit_index = 7; // starting at MSb since it goes from MSb -> LSb

		for (y = 0; y < height; y++)
		{
			for (x = 0; x < width; x++)
			{
				bool current_bit = get_bit(bitmap[current_map_index], current_bit_index);

				if (current_bit)
				{
					Display_put_pixel(display, position.x + x, position.y + y, pixel);
				}

				current_bit_index--;
				if (current_bit_index == -1)
				{
					current_bit_index = 7;
					current_map_index++;
				}
			}
		}
	}
}

/*
	draws a cropped bitmap at a given position, cropped meaning you can choose what part of the bitmap to draw.
	this is very useful when drawing animations for example.
*/
void Display_draw_bitmap_crop(Display *display, const uint8_t *bitmap, Rect crop, Vector2f position, bool flip, bool pixel)
{
	int x, y;
	for (x = 0; x < crop.size.x; x++)
	{
		for (y = 0; y < crop.size.y; y++)
		{
			uint8_t bitmap_x = flip ? crop.position.x + (crop.size.x - 1 - x) : crop.position.x + x;
			uint8_t bitmap_y = crop.position.y + y;
			if (bitmap_get_bit(bitmap, bitmap_x, bitmap_y))
			{
				Display_put_pixel(display, position.x + x, position.y + y, pixel);
			}
		}
	}
}

/*
	draws an animation at given frame. you have to specify the frame_size and frame yourself
	which are used to calculate what part of the whole animation (a bitmap) to draw.
*/
void Display_draw_animation(Display *display, const uint8_t *bitmap_animation, uint8_t frame_size, uint8_t frame, Vector2f position, bool flip, bool pixel)
{
	Rect crop = Rect_construct((Vector2f){frame * frame_size, 0}, (Vector2f){frame_size, bitmap_get_height(bitmap_animation)});
	Display_draw_bitmap_crop(display, bitmap_animation, crop, position, flip, pixel);
}

/*
	draws an ascii character at a given position.
	however, not everything is supported, only the following:
		"font table"
		------------
		ABCDEFGHIJKLMNOPQRSTUVWXYZ
		0123456789           +-*^=
		()[]{}<>/\|  _,.;:~'"!?#%&
*/
void Display_draw_char(Display *display, char c, Vector2f position, bool flip, bool pixel)
{
	// quickly checking against spaces since we won't have to draw anything if that's the case
	if (c == ' ') return;

	Vector2f crop_coord;

	if (c >= 'a' && c <= 'z')
	{
		crop_coord.x = c -= 'a';
		crop_coord.y = 0;
	}
	else if (c >= 'A' && c <= 'Z')
	{
		crop_coord.x = c -= 'A';
		crop_coord.y = 0;
	}
	else if (c >= '0' && c <= '9')
	{
		crop_coord.x = c -= '0';
		crop_coord.y = 1;
	}
	else
	/*
		note:
		we could structure our "font table" a bit more like the ASCII table
		to make these cases more efficient, but as of right now this works
		so why bother changing it? unless we need to due to performance issues...
	*/
	{
		switch (c)
		{
			case '+':  { crop_coord = (Vector2f){ 21, 1 }; break; }
			case '-':  { crop_coord = (Vector2f){ 22, 1 }; break; }
			case '*':  { crop_coord = (Vector2f){ 23, 1 }; break; }
			case '^':  { crop_coord = (Vector2f){ 24, 1 }; break; }
			case '=':  { crop_coord = (Vector2f){ 25, 1 }; break; }
			case '(':  { crop_coord = (Vector2f){  0, 2 }; break; }
			case ')':  { crop_coord = (Vector2f){  1, 2 }; break; }
			case '[':  { crop_coord = (Vector2f){  2, 2 }; break; }
			case ']':  { crop_coord = (Vector2f){  3, 2 }; break; }
			case '{':  { crop_coord = (Vector2f){  4, 2 }; break; }
			case '}':  { crop_coord = (Vector2f){  5, 2 }; break; }
			case '<':  { crop_coord = (Vector2f){  6, 2 }; break; }
			case '>':  { crop_coord = (Vector2f){  7, 2 }; break; }
			case '/':  { crop_coord = (Vector2f){  8, 2 }; break; }
			case '\\': { crop_coord = (Vector2f){  9, 2 }; break; } // >:(
			case '|':  { crop_coord = (Vector2f){ 10, 2 }; break; }
			case '_':  { crop_coord = (Vector2f){ 13, 2 }; break; }
			case ',':  { crop_coord = (Vector2f){ 14, 2 }; break; }
			case '.':  { crop_coord = (Vector2f){ 15, 2 }; break; }
			case ';':  { crop_coord = (Vector2f){ 16, 2 }; break; }
			case ':':  { crop_coord = (Vector2f){ 17, 2 }; break; }
			case '~':  { crop_coord = (Vector2f){ 18, 2 }; break; }
			case '\'': { crop_coord = (Vector2f){ 19, 2 }; break; } // >:(
			case '"':  { crop_coord = (Vector2f){ 20, 2 }; break; }
			case '!':  { crop_coord = (Vector2f){ 21, 2 }; break; }
			case '?':  { crop_coord = (Vector2f){ 22, 2 }; break; }
			case '#':  { crop_coord = (Vector2f){ 23, 2 }; break; }
			case '%':  { crop_coord = (Vector2f){ 24, 2 }; break; }
			case '&':  { crop_coord = (Vector2f){ 25, 2 }; break; }
			default: return; // no match found :(
		}
	}

	Rect crop = Rect_construct(
		(Vector2f){1 + crop_coord.x * (FONTSIZE + 1), 1 + crop_coord.y * (FONTSIZE + 1)},
		(Vector2f){FONTSIZE, FONTSIZE}
	);

	Display_draw_bitmap_crop(display, bitmap_font, crop, position, flip, pixel);
}

/*
	draws a string at a given position and alignment.
	you can also choose to display a background behind the string if you want.
	if a background is drawn the pixel boolean will dictate the color of the background,
	otherwise it will dictate the color of the text. this ensures that the text is always visible,
	unless the programmer does something stupid.
*/
void Display_draw_string(Display *display, const char *string, Vector2f position, Alignment align_x, Alignment align_y, bool flip, bool pixel, bool background)
{
	position = align(position, (Vector2f){bitmap_font_string_get_width(strlen(string), display->char_spacing), FONTSIZE}, align_x, align_y);

	if (background)
	{
		Rect background = Rect_construct(
			(Vector2f){
				position.x - 1, position.y - 1
			},
			(Vector2f){
				bitmap_font_string_get_width(strlen(string), display->char_spacing) + 2,
				FONTSIZE + 2
			}
		);

		Display_draw_rect(display, background, HOLLOW_OFF, pixel);

		pixel = !pixel; // inverting the pixel because we want the text to be visible over the background
	}

	int i;
	int char_count = strlen(string);

	// loops through each character and draws it to the right of the previous one
	for (i = 0; i < char_count; i++)
	{
		int index = flip ? char_count - 1 - i : i;
		char c = string[index];

		if (c == '\0') break; // breaking if null

		Vector2f char_position = {
			position.x + i * (FONTSIZE + display->char_spacing),
			position.y
		};

		Display_draw_char(display, c, char_position, flip, pixel);
	}
}
