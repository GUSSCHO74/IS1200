#pragma once

#include <stdbool.h>
#include <stdint.h>

/*
	just some stuff we didn't feel needed their own seperate files
	so we crammed them all in here
*/

bool get_bit(unsigned int bits, uint8_t index);

void toggle(bool *boolean);

float absf(float f);
